package function;

import java.util.concurrent.ConcurrentLinkedQueue;

public class UseDatabase {

    static public String dbName= new String();

}
